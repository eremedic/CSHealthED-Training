# CSHealthED EMS Training Platform

## File structure

```
cshealtched/
├── api/
│   └── generate.js     ← Vercel serverless function (holds your API key)
├── public/
│   ├── index.html      ← Landing page
│   └── builder.html    ← Curriculum builder
├── vercel.json         ← Routing config
└── package.json
```

---

## Deploy to Vercel (free, 5 minutes)

### Step 1 — Get your Anthropic API key
1. Go to https://console.anthropic.com
2. Sign in or create a free account
3. Click **API Keys** in the left sidebar
4. Click **Create Key** → copy the key (starts with `sk-ant-...`)

### Step 2 — Push to GitHub
1. Create a free account at https://github.com
2. Create a new repository (e.g. `cshealtched`)
3. Upload all files from this folder into the repo

### Step 3 — Deploy on Vercel
1. Go to https://vercel.com and sign in with GitHub
2. Click **Add New → Project**
3. Select your `cshealtched` GitHub repo
4. Click **Environment Variables** and add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your key from Step 1
5. Click **Deploy**

Your site will be live in ~60 seconds at `https://your-project.vercel.app`

---

## How the API key stays secret

- The key is stored in Vercel's encrypted environment variables
- `api/generate.js` runs as a serverless function — users can never see it
- The browser calls `/api/generate` on YOUR server, which calls Anthropic
- The key never appears in any HTML or JavaScript that users can inspect

---

## Local development

```bash
# Install Vercel CLI
npm install -g vercel

# Create a .env.local file
echo "ANTHROPIC_API_KEY=sk-ant-your-key-here" > .env.local

# Run locally
vercel dev

# Open http://localhost:3000
```
