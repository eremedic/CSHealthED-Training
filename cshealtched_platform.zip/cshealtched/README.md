# CSHealthED EMS Training Platform

A full-stack web application for generating EMS training curricula powered by Claude AI.

---

## How it works

- **Landing page** (`/`) — marketing page with features, provider levels, topic library
- **Builder** (`/builder`) — 4-step curriculum generator
- **API** (`/api/generate`) — server-side proxy that holds your Anthropic API key and calls Claude

Your API key lives only on the server. Users never see it.

---

## Deploy to Vercel (free, 5 minutes)

### Step 1 — Get your Anthropic API key
1. Go to https://console.anthropic.com
2. Sign in or create an account
3. Click **API Keys** in the left sidebar
4. Click **Create Key**, copy the key (starts with `sk-ant-...`)

### Step 2 — Deploy to Vercel
1. Go to https://vercel.com and sign in with GitHub
2. Click **Add New → Project**
3. Upload this folder (drag the `cshealtched` folder into Vercel, or push to a GitHub repo first)
4. Before clicking Deploy, click **Environment Variables**
5. Add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your key from Step 1
6. Click **Deploy**

Your site will be live at `https://your-project.vercel.app` in about 60 seconds.

---

## Deploy to Railway (alternative)

1. Go to https://railway.app and sign in
2. Click **New Project → Deploy from GitHub** (or upload folder)
3. In project settings → **Variables**, add `ANTHROPIC_API_KEY`
4. Railway auto-detects Node.js and runs `npm start`

---

## Run locally

```bash
# 1. Copy the env file and add your key
cp .env.example .env
# Edit .env and paste your ANTHROPIC_API_KEY

# 2. Load the env and start
ANTHROPIC_API_KEY=sk-ant-... node server.js

# 3. Open http://localhost:3000
```

No npm install needed — the server uses only Node.js built-in modules.

---

## File structure

```
cshealtched/
├── server.js          ← Node.js server (API proxy + static file serving)
├── package.json       ← Project config
├── vercel.json        ← Vercel deployment config
├── .env.example       ← Copy to .env for local development
└── public/
    ├── index.html     ← Landing page
    └── builder.html   ← Curriculum builder app
```
